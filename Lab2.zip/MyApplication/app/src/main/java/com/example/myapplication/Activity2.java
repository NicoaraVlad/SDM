package com.example.myapplication;

import android.app.Activity;

public class Activity2 extends Activity {
}
