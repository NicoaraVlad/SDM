package com.app.lab5;

import java.util.ArrayList;

public class Pojo {


        private String message;
        private int number;


        // Getter Methods

        public String getMessage() {
            return message;
        }

        public  int getNumber() {
            return number;
        }

        // Setter Methods

        public void setMessage(String message) {
            this.message = message;
        }

        public void setNumber(int number) {
            this.number = number;
        }
    }

